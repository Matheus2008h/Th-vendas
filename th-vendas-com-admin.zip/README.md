# TH Vendas — site + painel /admin

O site continua igual por fora. A novidade é o **/admin**: você entra com uma senha e edita
produtos, preços, estoque, Pix e contato sem mexer em código.

## Como publicar na Netlify
1. Suba esta pasta num repositório do GitHub e conecte na Netlify (ou use `netlify deploy --build --prod`).
   Arrastar só a pasta `dist` **não** funciona: a API do painel precisa da função em `netlify/functions`.
2. Em **Site configuration → Environment variables**, crie:
   - `ADMIN_PASSWORD` = a senha do painel (escolha uma forte)
3. Faça o deploy e abra `https://seu-site.netlify.app/admin`.

## Como usar o painel
- Abas no topo: Geral (contato, Pix, aviso), Blox Fruits, Free Fire, Streaming, Engajamento, Bots, Sites, Números, Tráfego.
- Toque num item para editar. Dá para adicionar, duplicar, reordenar (setas), ocultar do site ou apagar.
- Clique em **Salvar**: o site público já mostra as mudanças.

## Onde ficam os dados
- Edições ficam no Netlify Blobs (gratuito, persistente).
- Enquanto você não salvar nada, o site usa `data/catalog.json` (seus produtos de antes).
- `src/data.ts` continua como reserva caso a API esteja fora do ar.

## Arquivos novos
- `src/Admin.tsx` — painel
- `src/schema.ts` — campos de cada categoria (usado no painel e na validação)
- `src/catalog.ts` — carrega o catálogo salvo no site público
- `netlify/functions/api.mjs` — login + leitura/gravação
- `data/catalog.json` — catálogo inicial
