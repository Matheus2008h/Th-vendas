import { createContext, useContext, useState, useMemo, type ReactNode } from "react";
import { parsePrice } from "../pix";

export interface CartItem {
  id: string;
  name: string;
  price: string; // "R$ x,xx" — unit price
  category?: string;
  emoji?: string;
  qty: number;
}

export type CartProductInput = Omit<CartItem, "qty">;

interface CartContextValue {
  items: CartItem[];
  addItem: (product: CartProductInput) => void;
  removeItem: (id: string) => void;
  updateQty: (id: string, qty: number) => void;
  clearCart: () => void;
  totalCount: number;
  totalValue: number;
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  justAddedId: string | null;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [justAddedId, setJustAddedId] = useState<string | null>(null);

  const addItem = (product: CartProductInput) => {
    setItems((prev) => {
      const existing = prev.find((it) => it.id === product.id);
      if (existing) {
        return prev.map((it) =>
          it.id === product.id ? { ...it, qty: it.qty + 1 } : it
        );
      }
      return [...prev, { ...product, qty: 1 }];
    });
    setJustAddedId(product.id);
    setTimeout(() => setJustAddedId((cur) => (cur === product.id ? null : cur)), 1200);
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((it) => it.id !== id));
  };

  const updateQty = (id: string, qty: number) => {
    if (qty <= 0) {
      removeItem(id);
      return;
    }
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, qty } : it)));
  };

  const clearCart = () => setItems([]);

  const totalCount = useMemo(() => items.reduce((sum, it) => sum + it.qty, 0), [items]);
  const totalValue = useMemo(
    () => items.reduce((sum, it) => sum + parsePrice(it.price) * it.qty, 0),
    [items]
  );

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQty,
        clearCart,
        totalCount,
        totalValue,
        isOpen,
        openCart: () => setIsOpen(true),
        closeCart: () => setIsOpen(false),
        justAddedId,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
