import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, X, Plus, Minus, Trash2, QrCode, PackageOpen } from "lucide-react";
import { useCart } from "./CartContext";
import { usePayment } from "./PaymentContext";

export function FloatingCartButton() {
  const { totalCount, openCart } = useCart();

  return (
    <AnimatePresence>
      {totalCount > 0 && (
        <motion.button
          initial={{ scale: 0, rotate: 180 }}
          animate={{ scale: 1, rotate: 0 }}
          exit={{ scale: 0, rotate: 180 }}
          transition={{ type: "spring" }}
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.92 }}
          onClick={openCart}
          aria-label="Ver carrinho"
          className="fixed bottom-6 left-6 z-50 flex items-center gap-2 rounded-full bg-gradient-to-r from-red-600 to-red-800 px-4 py-3 text-white shadow-2xl shadow-red-600/50"
        >
          <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-red-500 opacity-30" />
          <ShoppingCart className="h-6 w-6" />
          <span className="hidden text-sm font-bold sm:inline">Carrinho</span>
          <span className="flex h-6 min-w-6 items-center justify-center rounded-full bg-white px-1.5 text-xs font-black text-red-700">
            {totalCount}
          </span>
        </motion.button>
      )}
    </AnimatePresence>
  );
}

export default function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQty, clearCart, totalValue } = useCart();
  const { openPayment } = usePayment();

  const handleCheckout = () => {
    if (items.length === 0) return;
    const cartItems = items.map((it) => ({ name: it.name, price: it.price, qty: it.qty }));
    openPayment({
      name: `Carrinho (${items.reduce((s, it) => s + it.qty, 0)} itens)`,
      price: `R$ ${totalValue.toFixed(2).replace(".", ",")}`,
      category: "Carrinho de Compras",
      items: cartItems,
    });
    closeCart();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[90] flex items-stretch justify-end bg-black/70 backdrop-blur-sm"
          onClick={closeCart}
        >
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 26, stiffness: 260 }}
            onClick={(e) => e.stopPropagation()}
            className="flex h-full w-full max-w-md flex-col border-l border-red-900/40 bg-gradient-to-b from-red-950/40 via-black to-black shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-red-900/40 bg-black/60 px-5 py-4">
              <div className="flex items-center gap-2">
                <ShoppingCart className="h-5 w-5 text-red-500" />
                <h3 className="font-brush text-2xl text-white blood-glow">Seu Carrinho</h3>
              </div>
              <button
                onClick={closeCart}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-red-900/40 bg-black/80 text-red-400 transition hover:border-red-500 hover:bg-red-950 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto px-5 py-4">
              {items.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center text-center text-slate-500">
                  <PackageOpen className="mb-3 h-12 w-12 text-red-900" />
                  <p className="text-sm">Seu carrinho está vazio.</p>
                  <p className="mt-1 text-xs">
                    Adicione produtos clicando no ícone de carrinho ao lado de "Comprar".
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {items.map((it) => (
                    <motion.div
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: 30 }}
                      key={it.id}
                      className="rounded-lg border border-red-900/30 bg-black/60 p-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          {it.category && (
                            <div className="text-[10px] uppercase tracking-widest text-red-500">
                              {it.category}
                            </div>
                          )}
                          <div className="truncate text-sm font-bold text-white">
                            {it.emoji ? `${it.emoji} ` : ""}
                            {it.name}
                          </div>
                          <div className="text-xs text-slate-400">{it.price} / un.</div>
                        </div>
                        <button
                          onClick={() => removeItem(it.id)}
                          className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md text-red-500/70 transition hover:bg-red-950 hover:text-red-400"
                          aria-label="Remover item"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>

                      <div className="mt-2 flex items-center justify-between">
                        <div className="flex items-center gap-1 rounded-md border border-red-900/40 bg-black/60">
                          <button
                            onClick={() => updateQty(it.id, it.qty - 1)}
                            className="flex h-7 w-7 items-center justify-center text-red-400 transition hover:bg-red-950"
                          >
                            <Minus size={12} />
                          </button>
                          <span className="w-6 text-center text-xs font-bold text-white">
                            {it.qty}
                          </span>
                          <button
                            onClick={() => updateQty(it.id, it.qty + 1)}
                            className="flex h-7 w-7 items-center justify-center text-red-400 transition hover:bg-red-950"
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                        <span className="font-brush text-lg text-red-500">
                          R${" "}
                          {(
                            parseFloat(
                              it.price.replace(/R\$\s*/gi, "").replace(/\./g, "").replace(",", ".")
                            ) * it.qty
                          )
                            .toFixed(2)
                            .replace(".", ",")}
                        </span>
                      </div>
                    </motion.div>
                  ))}

                  <button
                    onClick={clearCart}
                    className="mt-1 flex w-full items-center justify-center gap-1 text-xs text-slate-500 transition hover:text-red-400"
                  >
                    <Trash2 size={12} /> Limpar carrinho
                  </button>
                </div>
              )}
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div className="border-t border-red-900/40 bg-black/70 p-5">
                <div className="mb-4 flex items-center justify-between">
                  <span className="text-sm font-bold uppercase tracking-widest text-slate-400">
                    Total
                  </span>
                  <span className="font-brush text-3xl text-red-500 blood-glow">
                    R$ {totalValue.toFixed(2).replace(".", ",")}
                  </span>
                </div>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleCheckout}
                  className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-red-600 to-red-800 py-3.5 text-sm font-black uppercase tracking-widest text-white shadow-lg shadow-red-600/40"
                >
                  <QrCode className="h-5 w-5" />
                  Finalizar Compra com PIX
                </motion.button>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
