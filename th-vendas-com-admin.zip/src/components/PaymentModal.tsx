import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { QRCodeSVG } from "qrcode.react";
import {
  X,
  Copy,
  Check,
  Clock,
  Loader2,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Sparkles,
} from "lucide-react";
import {
  generatePixPayload,
  parsePrice,
  buildReceiptWhatsLink,
  PIX,
} from "../pix";

// WhatsApp Icon
const WhatsIcon = ({ className = "h-5 w-5" }: { className?: string }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 24 24">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

export interface PaymentProduct {
  name: string;
  price: string;
  category?: string;
  notice?: string;
  /** When checking out multiple products from the cart at once */
  items?: { name: string; price: string; qty: number }[];
}

interface Props {
  product: PaymentProduct | null;
  onClose: () => void;
}

type Status = "pending" | "checking" | "confirmed" | "expired";

const EXPIRATION_MINUTES = 15;

export default function PaymentModal({ product, onClose }: Props) {
  const [status, setStatus] = useState<Status>("pending");
  const [copied, setCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState(EXPIRATION_MINUTES * 60);
  const [checking, setChecking] = useState(false);

  // Generate PIX payload once per product
  const { payload, txId, amount } = useMemo(() => {
    if (!product) return { payload: "", txId: "", amount: 0 };
    const value = parsePrice(product.price);
    const id = "TH" + Date.now().toString().slice(-10);
    return {
      payload: generatePixPayload({ amount: value, txId: id }),
      txId: id,
      amount: value,
    };
  }, [product]);

  // Reset state when product changes
  useEffect(() => {
    if (product) {
      setStatus("pending");
      setCopied(false);
      setTimeLeft(EXPIRATION_MINUTES * 60);
    }
  }, [product]);

  // Countdown timer
  useEffect(() => {
    if (!product || status === "confirmed" || status === "expired") return;
    const interval = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          setStatus("expired");
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [product, status]);

  // Prevent body scroll when modal is open
  useEffect(() => {
    if (product) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [product]);

  const handleCopy = () => {
    navigator.clipboard.writeText(payload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Simulates payment verification (in real integration this would call a backend endpoint)
  const handleCheckPayment = () => {
    setChecking(true);
    setStatus("checking");
    // In production, replace this with a real API call to check PIX status
    setTimeout(() => {
      setChecking(false);
      setStatus("confirmed");
    }, 3500);
  };

  const mm = Math.floor(timeLeft / 60).toString().padStart(2, "0");
  const ss = (timeLeft % 60).toString().padStart(2, "0");

  return (
    <AnimatePresence>
      {product && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-black/85 p-4 backdrop-blur-md"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, y: 20, opacity: 0 }}
            transition={{ type: "spring", damping: 20 }}
            onClick={(e) => e.stopPropagation()}
            className="relative my-8 w-full max-w-lg overflow-hidden rounded-2xl border border-red-500/40 bg-gradient-to-b from-red-950/40 via-black to-black shadow-2xl shadow-red-600/40"
          >
            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute right-3 top-3 z-10 flex h-9 w-9 items-center justify-center rounded-full border border-red-900/40 bg-black/80 text-red-400 transition hover:border-red-500 hover:bg-red-950 hover:text-white"
            >
              <X size={18} />
            </button>

            {/* HEADER */}
            <div className="border-b border-red-900/40 bg-gradient-to-r from-red-950/60 to-black/80 p-5">
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-red-600 to-red-900 font-black text-white shadow-lg shadow-red-600/40">
                  TH
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-red-400">
                    Pagamento PIX
                  </div>
                  <div className="font-brush text-lg text-white blood-glow">
                    TH Vendas — Checkout
                  </div>
                </div>
              </div>
            </div>

            {/* PRODUCT INFO */}
            <div className="border-b border-red-900/30 bg-black/60 px-5 py-3">
              {product.items && product.items.length > 0 ? (
                <>
                  <div className="mb-2 flex items-center justify-between">
                    <div className="text-[10px] uppercase tracking-widest text-red-500">
                      Carrinho ({product.items.reduce((s, it) => s + it.qty, 0)} itens)
                    </div>
                    <div className="text-right">
                      <div className="font-brush text-2xl text-red-500 blood-glow">
                        R$ {amount.toFixed(2).replace(".", ",")}
                      </div>
                    </div>
                  </div>
                  <div className="max-h-32 space-y-1 overflow-y-auto pr-1">
                    {product.items.map((it, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between gap-2 text-xs text-slate-300"
                      >
                        <span className="truncate">
                          <span className="text-red-400">{it.qty}x</span> {it.name}
                        </span>
                        <span className="flex-shrink-0 text-slate-400">{it.price}</span>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="flex items-center justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    {product.category && (
                      <div className="text-[10px] uppercase tracking-widest text-red-500">
                        {product.category}
                      </div>
                    )}
                    <div className="truncate text-sm font-bold text-white">
                      {product.name}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] uppercase tracking-widest text-slate-500">
                      Total
                    </div>
                    <div className="font-brush text-2xl text-red-500 blood-glow">
                      R$ {amount.toFixed(2).replace(".", ",")}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* CONTENT */}
            <div className="p-5">
              {/* PENDING / CHECKING */}
              {(status === "pending" || status === "checking") && (
                <>
                  {/* Product notice / warning */}
                  {product.notice && (
                    <div className="mb-4 rounded-lg border border-yellow-500/40 bg-yellow-950/20 p-3 text-xs text-yellow-200">
                      <div className="mb-1 flex items-center gap-1 font-bold uppercase tracking-widest text-yellow-400">
                        <AlertCircle size={12} /> Aviso importante
                      </div>
                      {product.notice}
                    </div>
                  )}

                  {/* Timer */}
                  <div className="mb-4 flex items-center justify-between rounded-lg border border-yellow-500/30 bg-yellow-950/20 px-4 py-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-yellow-400">
                      <Clock size={14} />
                      QR Code expira em:
                    </div>
                    <div className="font-mono text-lg font-black text-yellow-400">
                      {mm}:{ss}
                    </div>
                  </div>

                  {/* QR CODE */}
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="mx-auto mb-4 flex w-fit flex-col items-center rounded-xl bg-white p-4 shadow-2xl"
                  >
                    <QRCodeSVG
                      value={payload}
                      size={220}
                      level="M"
                      marginSize={0}
                      imageSettings={{
                        src:
                          "data:image/svg+xml;utf8," +
                          encodeURIComponent(
                            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><rect width="40" height="40" rx="8" fill="#dc2626"/><text x="50%" y="55%" text-anchor="middle" font-family="Arial Black,sans-serif" font-size="16" font-weight="900" fill="white">TH</text></svg>'
                          ),
                        height: 40,
                        width: 40,
                        excavate: true,
                      }}
                    />
                    <div className="mt-3 flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-slate-700">
                      <Sparkles size={10} className="text-red-600" />
                      PIX INSTANTÂNEO
                    </div>
                  </motion.div>

                  {/* Copia e cola */}
                  <div className="mb-4">
                    <div className="mb-1 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                      PIX Copia e Cola
                    </div>
                    <div className="flex overflow-hidden rounded-lg border border-red-900/40">
                      <div className="min-w-0 flex-1 truncate bg-black/60 px-3 py-2 font-mono text-[11px] text-slate-300">
                        {payload}
                      </div>
                      <button
                        onClick={handleCopy}
                        className={`flex items-center gap-1 px-3 text-xs font-bold uppercase tracking-widest transition ${
                          copied
                            ? "bg-green-600 text-white"
                            : "bg-red-600 text-white hover:bg-red-700"
                        }`}
                      >
                        {copied ? (
                          <>
                            <Check size={14} /> Copiado
                          </>
                        ) : (
                          <>
                            <Copy size={14} /> Copiar
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Chave PIX display */}
                  <div className="mb-4 rounded-lg border border-red-900/30 bg-red-950/10 p-3">
                    <div className="text-[10px] font-bold uppercase tracking-widest text-red-500">
                      Chave PIX (Telefone)
                    </div>
                    <div className="mt-1 break-all font-mono text-[11px] text-slate-300">
                      {PIX.display}
                    </div>
                    <div className="mt-1 text-[10px] text-slate-500">
                      Beneficiário: <span className="text-white font-bold">{PIX.merchant}</span>
                    </div>
                  </div>

                  {/* Instructions */}
                  <div className="mb-5 rounded-lg border border-blue-500/20 bg-blue-950/20 p-3 text-xs text-slate-300">
                    <div className="mb-1 flex items-center gap-1 font-bold text-blue-400">
                      <ShieldCheck size={12} /> Como pagar:
                    </div>
                    <ol className="ml-4 list-decimal space-y-0.5 text-[11px]">
                      <li>Abra o app do seu banco</li>
                      <li>
                        Escolha <b>PIX → Pagar com QR Code</b> ou{" "}
                        <b>Copia e Cola</b>
                      </li>
                      <li>Confirme o pagamento</li>
                      <li>
                        Clique em <b>"Já paguei"</b> abaixo
                      </li>
                    </ol>
                  </div>

                  {/* Check payment button */}
                  <button
                    onClick={handleCheckPayment}
                    disabled={checking}
                    className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-red-600 to-red-800 py-3 text-sm font-black uppercase tracking-widest text-white shadow-lg shadow-red-600/40 transition hover:scale-[1.02] active:scale-100 disabled:opacity-60"
                  >
                    {checking ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        Verificando pagamento...
                      </>
                    ) : (
                      <>
                        <Check size={16} />
                        Já paguei — Verificar
                      </>
                    )}
                  </button>

                  <div className="mt-3 text-center text-[10px] text-slate-500">
                    Transação: <span className="font-mono text-slate-400">{txId}</span>
                  </div>
                </>
              )}

              {/* CONFIRMED */}
              {status === "confirmed" && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center"
                >
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: "spring", damping: 12 }}
                    className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-green-500 to-emerald-700 shadow-2xl shadow-green-500/50"
                  >
                    <CheckCircle2 className="h-14 w-14 text-white" strokeWidth={2.5} />
                  </motion.div>

                  <h3 className="font-brush text-3xl text-green-400 blood-glow">
                    Pagamento Confirmado!
                  </h3>
                  <p className="mt-2 text-sm text-slate-300">
                    Seu pagamento foi aprovado com sucesso! 🎉
                  </p>

                  <div className="my-5 rounded-lg border border-green-500/30 bg-green-950/20 p-4 text-left">
                    <div className="text-[10px] font-bold uppercase tracking-widest text-green-400">
                      ⚠️ Última etapa importante
                    </div>
                    <p className="mt-1 text-xs text-slate-300">
                      Clique no botão abaixo para enviar seu{" "}
                      <b className="text-white">comprovante de pagamento</b> direto no WhatsApp
                      do ADM Theus. Após conferirmos, seu produto será liberado imediatamente!
                    </p>
                  </div>

                  <motion.a
                    initial={{ scale: 0.9 }}
                    animate={{ scale: 1 }}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    href={buildReceiptWhatsLink(product.name, product.price, txId, product.items)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-green-500 to-green-700 py-3.5 text-sm font-black uppercase tracking-widest text-white shadow-lg shadow-green-500/50 animate-pulse-red"
                  >
                    <WhatsIcon className="h-5 w-5" />
                    Enviar Comprovante no WhatsApp
                  </motion.a>

                  <p className="mt-3 text-[10px] text-slate-500">
                    Você será redirecionado para o WhatsApp com a mensagem já pronta. Anexe o
                    comprovante e envie!
                  </p>
                </motion.div>
              )}

              {/* EXPIRED */}
              {status === "expired" && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center"
                >
                  <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-red-600 to-red-900 shadow-2xl shadow-red-600/50">
                    <AlertCircle className="h-14 w-14 text-white" strokeWidth={2.5} />
                  </div>
                  <h3 className="font-brush text-3xl text-red-500 blood-glow">
                    QR Code Expirado
                  </h3>
                  <p className="mt-2 text-sm text-slate-300">
                    O tempo para pagamento acabou. Feche esta janela e clique em comprar
                    novamente para gerar um novo QR Code.
                  </p>
                  <button
                    onClick={onClose}
                    className="mt-5 w-full rounded-lg bg-red-600 py-3 text-sm font-black uppercase tracking-widest text-white transition hover:bg-red-700"
                  >
                    Fechar
                  </button>
                </motion.div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
