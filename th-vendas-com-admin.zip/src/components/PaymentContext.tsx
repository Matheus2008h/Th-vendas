import { createContext, useContext, useState, type ReactNode } from "react";
import PaymentModal, { type PaymentProduct } from "./PaymentModal";

interface PaymentContextValue {
  openPayment: (product: PaymentProduct) => void;
}

const PaymentContext = createContext<PaymentContextValue | null>(null);

export function PaymentProvider({ children }: { children: ReactNode }) {
  const [product, setProduct] = useState<PaymentProduct | null>(null);

  return (
    <PaymentContext.Provider value={{ openPayment: setProduct }}>
      {children}
      <PaymentModal product={product} onClose={() => setProduct(null)} />
    </PaymentContext.Provider>
  );
}

export function usePayment() {
  const ctx = useContext(PaymentContext);
  if (!ctx) throw new Error("usePayment must be used within PaymentProvider");
  return ctx;
}
